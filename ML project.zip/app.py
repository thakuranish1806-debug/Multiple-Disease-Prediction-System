import streamlit as st
from logic import diabetes_risk, heart_risk, parkinson_risk

st.set_page_config(page_title="Multiple Disease System", layout="wide")

# ---------------- CUSTOM STYLE ----------------
st.markdown("""
<style>
.stApp {
    background-color: #0e1117;
}
h1, h2, h3 {
    color: white;
}
label {
    color: #9ca3af !important;
}
.stButton>button {
    background-color: #1f2937;
    color: white;
    border-radius: 10px;
    height: 45px;
}
</style>
""", unsafe_allow_html=True)

# ---------------- SIDEBAR ----------------
st.sidebar.title("🧠 Multiple Disease Prediction System")

menu = st.sidebar.radio("", [
    "Diabetes Prediction",
    "Heart Disease Prediction",
    "Parkinson Prediction"
])

# ---------------- DIABETES ----------------
if menu == "Diabetes Prediction":

    st.title("Diabetes Prediction using ML")

    col1, col2, col3 = st.columns(3)

    with col1:
        preg = st.number_input("Number of Pregnancies")
        skin = st.number_input("Skin Thickness")
        dpf = st.number_input("Diabetes Pedigree Function")

    with col2:
        glucose = st.number_input("Glucose Level")
        insulin = st.number_input("Insulin Level")
        age = st.number_input("Age")

    with col3:
        bp = st.number_input("Blood Pressure")
        bmi = st.number_input("BMI")

    st.write("")

    if st.button("Diabetes Test Result"):
        result = diabetes_risk(preg, glucose, bp, skin, insulin, bmi, dpf, age)
        st.success(result)

# ---------------- HEART ----------------
elif menu == "Heart Disease Prediction":

    st.title("Heart Disease Prediction")

    col1, col2 = st.columns(2)

    with col1:
        age = st.number_input("Age")
        chol = st.number_input("Cholesterol")

    with col2:
        bp = st.number_input("Blood Pressure")
        hr = st.number_input("Heart Rate")

    if st.button("Heart Test Result"):
        result = heart_risk(age, chol, bp, hr)
        st.success(result)

# ---------------- PARKINSON ----------------
elif menu == "Parkinson Prediction":

    st.title("Parkinson Prediction")

    col1, col2 = st.columns(2)

    with col1:
        voice = st.number_input("Voice Frequency")

    with col2:
        jitter = st.number_input("Jitter")

    if st.button("Parkinson Test Result"):
        result = parkinson_risk(voice, jitter)
        st.success(result)