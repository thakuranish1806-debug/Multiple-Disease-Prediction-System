import pickle
import numpy as np

# ---------------- LOAD MODELS ----------------
try:
    diabetes_model = pickle.load(open("diabetes_model.pkl", "rb"))
except:
    diabetes_model = None

try:
    heart_model = pickle.load(open("heart_model.pkl", "rb"))
except:
    heart_model = None

try:
    parkinson_model = pickle.load(open("parkinson_model.pkl", "rb"))
except:
    parkinson_model = None


# ---------------- DIABETES ----------------
def diabetes_risk(preg, glucose, bp, skin, insulin, bmi, dpf, age):
    if diabetes_model is None:
        return "Diabetes model not trained ❌"

    data = np.array([[preg, glucose, bp, skin, insulin, bmi, dpf, age]])

    pred = diabetes_model.predict(data)[0]
    prob = diabetes_model.predict_proba(data)[0][1]

    if pred == 1:
        return f"Diabetic (Risk: {round(prob*100,2)}%)"
    else:
        return f"Not Diabetic (Confidence: {round((1-prob)*100,2)}%)"


# ---------------- HEART ----------------
def heart_risk(age, chol, bp, hr):
    if heart_model is None:
        return "Heart model not trained ❌"

    data = np.array([[age, chol, bp, hr]])

    pred = heart_model.predict(data)[0]

    if pred == 1:
        return "High Heart Disease Risk ❤️"
    else:
        return "Low Risk 💚"


# ---------------- PARKINSON ----------------
def parkinson_risk(voice, jitter):
    if parkinson_model is None:
        return "Parkinson model not trained ❌"

    data = np.array([[voice, jitter]])

    pred = parkinson_model.predict(data)[0]

    if pred == 1:
        return "Parkinson Risk 🧬"
    else:
        return "Normal 💚"