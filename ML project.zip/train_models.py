print("FILE STARTED 🚀")
import pandas as pd
import pickle
from sklearn.linear_model import LogisticRegression

try:
    print("Starting training...")

    # ---------------- DIABETES ----------------
    df = pd.read_csv("diabetes.csv")
    X = df.drop("Outcome", axis=1)
    y = df["Outcome"]

    model = LogisticRegression(max_iter=1000)
    model.fit(X, y)

    pickle.dump(model, open("diabetes_model.pkl", "wb"))
    print("Diabetes model trained ✅")

    # ---------------- HEART ----------------
    df = pd.read_csv("heart.csv")
    X = df.drop("target", axis=1)
    y = df["target"]

    model = LogisticRegression()
    model.fit(X, y)

    pickle.dump(model, open("heart_model.pkl", "wb"))
    print("Heart model trained ✅")

    # ---------------- PARKINSON ----------------
    df = pd.read_csv("parkinson.csv")
    X = df.drop("target", axis=1)
    y = df["target"]

    model = LogisticRegression()
    model.fit(X, y)

    pickle.dump(model, open("parkinson_model.pkl", "wb"))
    print("Parkinson model trained ✅")

    print("ALL MODELS READY 🚀")

except Exception as e:
    print("ERROR:", e)